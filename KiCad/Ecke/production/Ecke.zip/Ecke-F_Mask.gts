G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-05-17T11:01:55+02:00*
G04 #@! TF.ProjectId,Ecke,45636b65-2e6b-4696-9361-645f70636258,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-05-17 11:01:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMHorizOval*
0 Thick line with rounded ends*
0 $1 width*
0 $2 $3 position (X,Y) of the first rounded end (center of the circle)*
0 $4 $5 position (X,Y) of the second rounded end (center of the circle)*
0 Add line between two ends*
20,1,$1,$2,$3,$4,$5,0*
0 Add two circle primitives to create the rounded ends*
1,1,$1,$2,$3*
1,1,$1,$4,$5*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10RotRect,1.700000X1.700000X30.000000*%
%ADD11HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD12C,3.600000*%
%ADD13RotRect,1.700000X1.700000X150.000000*%
%ADD14HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD15R,1.700000X1.700000*%
%ADD16O,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X-2008570Y9915998D03*
D11*
X-738570Y7716293D03*
X531430Y5516589D03*
X1801430Y3316884D03*
X3071430Y1117180D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H1*
X-4548566Y2577182D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J2*
X-12168569Y1117181D03*
D14*
X-10898569Y3316886D03*
X-9628569Y5516590D03*
X-8358569Y7716295D03*
X-7088569Y9915999D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J1*
X-5842000Y18796000D03*
D16*
X-3302000Y18796000D03*
X-5842000Y16256000D03*
X-3302000Y16255999D03*
X-5842001Y13716001D03*
X-3302000Y13716000D03*
G04 #@! TD*
M02*
