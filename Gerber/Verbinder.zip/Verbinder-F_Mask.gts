G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-05-17T11:15:54+02:00*
G04 #@! TF.ProjectId,Verbinder,56657262-696e-4646-9572-2e6b69636164,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-05-17 11:15:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMHorizOval*
0 Thick line with rounded ends*
0 $1 width*
0 $2 $3 position (X,Y) of the first rounded end (center of the circle)*
0 $4 $5 position (X,Y) of the second rounded end (center of the circle)*
0 Add line between two ends*
20,1,$1,$2,$3,$4,$5,0*
0 Add two circle primitives to create the rounded ends*
1,1,$1,$2,$3*
1,1,$1,$4,$5*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD11RotRect,1.700000X1.700000X150.000000*%
%ADD12HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD13RotRect,1.700000X1.700000X30.000000*%
%ADD14HorizOval,1.700000X0.000000X0.000000X0.000000X0.000000X0*%
%ADD15RotRect,1.700000X1.700000X210.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J1*
X-3443142Y14059216D03*
X-5642847Y15329216D03*
X-2173143Y16258920D03*
X-4372847Y17528920D03*
X-903142Y18458625D03*
D11*
X-3102847Y19728625D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J4*
X12437507Y15795330D03*
D13*
X13707507Y13595625D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J3*
X-168494Y13635069D03*
D11*
X1101506Y15834774D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J2*
X19181859Y15289773D03*
X16982154Y14019773D03*
X17911859Y17489477D03*
X15712154Y16219477D03*
X16641859Y19689182D03*
D15*
X14442154Y18419182D03*
G04 #@! TD*
M02*
